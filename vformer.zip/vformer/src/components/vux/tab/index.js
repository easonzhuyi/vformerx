import Tab from './tab'
import TabItem from './tab-item'

export {
  Tab,
  TabItem
}
